import os

def is_image(file_path):
    return file_path.lower().endswith(('.png', '.jpg', '.jpeg'))

def is_video(file_path):
    return file_path.lower().endswith(('.mp4', '.avi', '.mov'))