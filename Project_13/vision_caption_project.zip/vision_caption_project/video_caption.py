import cv2
from image_caption import generate_image_caption

def generate_video_caption(video_path, frame_interval=30):
    cap = cv2.VideoCapture(video_path)

    captions = []
    frame_count = 0

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        # Take every nth frame
        if frame_count % frame_interval == 0:
            temp_path = "temp_frame.jpg"
            cv2.imwrite(temp_path, frame)

            caption = generate_image_caption(temp_path)
            captions.append(caption)

        frame_count += 1

    cap.release()

    # Combine captions
    final_caption = " ".join(captions)
    return final_caption