from flask import Flask, render_template, request, redirect, url_for, session, flash
import os
import json

from image_caption import generate_image_caption
from video_caption import generate_video_caption
from utils import is_image, is_video

app = Flask(__name__)
app.secret_key = "secret123"

UPLOAD_FOLDER = "static/uploads"
USERS_FILE = "users.json"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ---------- AUTH ----------
def load_users():
    if not os.path.exists(USERS_FILE):
        return {}
    with open(USERS_FILE, "r") as f:
        return json.load(f)


def save_users(users):
    with open(USERS_FILE, "w") as f:
        json.dump(users, f, indent=4)


# ---------- ROUTES ----------
@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        users = load_users()
        if email in users and users[email] == password:
            session["user"] = email
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid credentials")

    return render_template("login.html")


@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        users = load_users()
        if email in users:
            flash("User already exists")
        else:
            users[email] = password
            save_users(users)
            flash("Account created! Please login.")
            return redirect(url_for("login"))

    return render_template("signup.html")


@app.route("/dashboard", methods=["GET", "POST"])
def dashboard():
    if "user" not in session:
        return redirect(url_for("login"))

    caption = None

    if request.method == "POST":
        file = request.files["file"]
        if file:
            path = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(path)

            if is_image(path):
                caption = generate_image_caption(path)
            elif is_video(path):
                caption = generate_video_caption(path)
            else:
                caption = "Unsupported format"

    return render_template("dashboard.html", caption=caption, user=session["user"])


@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect(url_for("login"))


if __name__ == "__main__":
    app.run(debug=True, port=5000)


